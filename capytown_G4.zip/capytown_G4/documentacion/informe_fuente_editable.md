# RC-0 — Calibración y validación del RosCar2
**Robótica ESAN 2026-2 · Sección S-004 · Grupo 4**  
**Integrantes:** Karina Vera Arias (Integración); Daryl Agurto Chavez (Control); Daniela Rios Flores (Planificación); Luanna Fuentes Lopez (Percepción).  
**ROS_DOMAIN_ID observado:** 20

## 1. Objetivo y referencia previa
Calibrar el radio efectivo **r** con una recta y el ancho efectivo **b_eff** con un giro de 360°, y validar la odometría en A4. Como referencia teórica, avanzar a 0.10 m/s durante 10 s equivale a 1.00 m. **Predicción escrita antes de medir:** no se ha aportado el registro original; incorporarlo solamente si existe una evidencia previa.

## 2. Calibración en A3: recta de 1 m
| Corrida | r (m) | Físico (m) | Odometría (m) | Error |
| --- | ---: | ---: | ---: | ---: |
| 1 | 0.03250 | 1.128 | 1.40095 | 24.20 % |
| 2 | 0.03250 | 1.050 | 1.09725 | 4.50 % |
| 3 | 0.03110 | 1.050 | 1.04134 | **0.83 %** |

La tercera corrida satisfizo el criterio de error de recta ≤ 2 %. Los desvíos laterales físicos de A3 no se registraron.

## 3. Calibración angular A3: giro horario
Se realizaron cinco iteraciones: 380°, 345°, 375°, 370° y **360° físicos**. La última registró **b_eff=0.2278 m** y error angular físico de **0.00 %**. El ROSbag principal indica **-363.04°** odométricos acumulados.

## 4. Validación en A4
| Prueba | Física | Odometría | Desvío de posición según /odom |
| --- | ---: | ---: | --- |
| Recta 1 | ≈1.05 m | 1.0498 m | y=-0.0219 m |
| Recta 2 | ≈1.05 m | 1.05331 m | y=-0.01710 m |
| Giro antihorario | ≈330°–340° (rango observado) | +362.06° | x=+0.004 m; y=+0.008 m |

El CSV original `validacion.csv` solo contiene las dos rectas. Se documenta el giro por separado como una medición física aproximada; no debe presentarse como exacta.

## 5. Gráficas, resultados y discusión
El script `plot_odom.py` procesó cuatro ROSbags SQLite3 y produjo **ocho gráficos PNG**: cuatro trayectorias X-Y y cuatro curvas de ángulo acumulado frente al tiempo. Las rectas A4 conservaron ≈1.05 m, pero la validación angular antihoraria presentó una diferencia apreciable entre odometría y giro físico. El deslizamiento lateral, la superficie y la dirección de rotación pueden contribuir al error.

**Trazabilidad de calibración:** después de la validación original se ajustó el YAML final a **r=0.03110 m** y **b_eff=0.2310 m**. Un ensayo horario posterior con -0.39 rad/s, objetivo odométrico 360°, logró ≈359° físicos. El ensayo antihorario que consiguió ≈360° físicos utilizó el **objetivo compensado de 368°**: no constituye una validación original sin compensación. Las pruebas se distinguen en `registro_ajustes_posteriores.csv`.

**Evidencias:** `linea_recta.csv`, `calibration_log.csv`, `validacion.csv`, `validacion_giro_complementaria.csv`, `registro_ajustes_posteriores.csv`, `setup_log.txt`, `bags/`, `plots/`. El reloj de la Raspberry Pi tenía una fecha incorrecta de julio de 2026.
