# RC-0 | Primer arranque y calibración del RosCar2

**Universidad:** ESAN, Robótica 2026-2  
**Sección/variante:** S-004  
**Equipo / grupo:** Grupo 4  
**Integrantes y roles:**

| Integrante | Rol |
| --- | --- |
| Karina Vera Arias | Integración |
| Daryl Agurto Chavez | Control |
| Daniela Rios Flores | Planificación |
| Luanna Fuentes Lopez | Percepción |  

**Robot:** RosCar2 (Raspberry Pi + ESP32, ROS 2)  
**Dominio observado:** `ROS_DOMAIN_ID=20`  
**Fecha de realización:** octubre de 2026; el reloj del robot registra incorrectamente fechas del 15 de julio de 2026.

## 1. Objetivo

Verificar el arranque y comunicación del RosCar2, calibrar su odometría en recta y giro sobre la variante A3, y validar el modelo en la variante A4. Documentar los datos medidos, las limitaciones observadas y las gráficas de ROSbag2.

## 2. Configuración registrada al final

| Parámetro | Valor |
| --- | ---: |
| `wheel_radius` (`r`) | **0.03110 m** |
| `wheel_separation` (`b_eff`) | **0.2310 m** |
| `firmware_wheel_radius` | 0.0325 m (sin modificar) |
| `firmware_wheel_separation` | 0.2400 m (sin modificar) |
| ROS domain ID observado | 20 |
| ROSbag2 | `sqlite3` |

**Trazabilidad importante:** `calibration_log.csv` termina con `b_eff=0.2278 m`, valor con el que se obtuvo aproximadamente 360° físicos en la iteración 5 de A3. El archivo YAML final contiene **0.2310 m** porque se realizaron ajustes experimentales **posteriores** a la validación original; no deben atribuirse retroactivamente al historial de calibración A3. Véase `registro_ajustes_posteriores.csv`.

## 3. Resultados de la recta A3

| Corrida | Radio (m) | Distancia física (m) | Odómetro (m) | Error registrado |
| --- | ---: | ---: | ---: | ---: |
| 1 | 0.03250 | 1.128 | 1.40095 | 24.20 % |
| 2 | 0.03250 | 1.050 | 1.09725 | 4.50 % |
| 3 | 0.03110 | 1.050 | 1.04134 | **0.83 %** |

En la tercera corrida se cumplió el umbral de error de recta menor o igual al 2 %. Los desvíos laterales físicos de estas tres corridas no se registraron en `linea_recta.csv`.

## 4. Calibración angular A3

`calibration_log.csv` conserva cinco iteraciones de ajuste, con ángulos físicos medidos de 380°, 345°, 375°, 370° y 360°. La quinta registró **0.00 % de error físico** con `b_eff=0.2278 m`. El ROSbag principal `bags/rc0_giro` muestra un ángulo odométrico acumulado de **-363.04°** (signo negativo = giro horario). Este dato proviene del intervalo grabado y no equivale exactamente a la medición manual de la iteración.

## 5. Validación A4

- **Recta 1:** distancia física aproximadamente 1.05 m, odometría 1.0498 m; desvío `y=-0.0219 m`.
- **Recta 2:** distancia física aproximadamente 1.05 m, odometría 1.05331 m; desvío `y=-0.01710 m`.
- **Giro antihorario original:** el ROSbag `rc0_val_giro` acumula **+362.06°** según `plot_odom.py`. Durante las pruebas se observó físicamente un giro aproximado de **330°–340°**, por lo que hubo una discrepancia de giro. No existe una tercera fila de giro en el CSV `validacion.csv` original; se deja registrada por separado como evidencia aproximada en `validacion_giro_complementaria.csv`.

El objetivo 368° usado en un ensayo antihorario posterior es **una compensación**, no la validación original a 360° sin ajustes.

## 6. Diagnóstico posterior (no confundir con la validación original)

Con `b_eff=0.2310 m`, un giro horario a **-0.39 rad/s** y objetivo odométrico 360° alcanzó aproximadamente **359° físicos**; el desplazamiento final estimado por odometría fue **0.56 cm**. A **-0.37 rad/s**, con el mismo objetivo, se observaron **365° físicos**, ángulo odométrico reportado ~360.2°, y desplazamiento por odometría **0.81 cm**, con pequeño movimiento físico a la izquierda. En otro ensayo antihorario a **+0.39 rad/s**, un objetivo odométrico **compensado de 368°** produjo aproximadamente **360° físicos**. Los ensayos no prueban por sí solos una validación estricta a 360° en ambos sentidos con parámetros sin cambiar.

## 7. Gráficos de odometría (E8)

Se generaron 8 PNG, dos por cada bag. La gráfica `_xy` presenta posición X-Y, inicio/fin y desvío; `_theta` presenta orientación desenvuelta (grados) frente al tiempo. Los cuatro bags principales son:

- `bags/rc0_recta/` — recta A3; resultado de script: x=+1.041 m, y=-0.033 m, ángulo=-3.03°.
- `bags/rc0_giro/` — giro horario A3; x=+0.001 m, y=-0.008 m, ángulo=-363.04°.
- `bags/rc0_val_recta/` — recta A4; x=+1.050 m, y=-0.022 m, ángulo=-3.42°.
- `bags/rc0_val_giro/` — giro antihorario A4; x=+0.004 m, y=+0.008 m, ángulo=+362.06°.

Para regenerar (en el contenedor ROS 2, con `source ../install/setup.bash`, desde `rc0`):

```bash
python3 plot_odom.py bags/rc0_recta
python3 plot_odom.py bags/rc0_giro
python3 plot_odom.py bags/rc0_val_recta
python3 plot_odom.py bags/rc0_val_giro
```

## 8. Estructura esperada para entregar

```text
capytown_G4/
├── README.md
├── informe.pdf
├── config/wheel_params.yaml
├── linea_recta.csv
├── calibration_log.csv
├── validacion.csv
├── validacion_giro_complementaria.csv
├── registro_ajustes_posteriores.csv
├── setup_log.txt
├── bags/
│   ├── rc0_recta/
│   ├── rc0_giro/
│   ├── rc0_val_recta/
│   └── rc0_val_giro/
├── plots/                  # 8 archivos PNG
└── capytown_esan/plot_odom.py
```

La grabación adicional `rc0_val_recta_c2/` puede adjuntarse como evidencia complementaria; no reemplaza las cuatro carpetas principales.

## 9. Puntos para revisión antes de entregar

1. Recuperar la **predicción escrita antes de las mediciones**, si existe: no reconstruirla después como si hubiera sido registrada antes.
2. Revisar si el docente exige integrar el giro a `validacion.csv` (actualmente solo registra dos rectas). El CSV complementario explicita que la lectura física del giro es aproximada.
3. Revisar los ocho PNG visualmente y corroborar que se leen los ejes y marcadores.
4. Explicar por qué el valor final de `b_eff` es distinto del historial original.
5. Confirmar el formato y nomenclatura de repositorio exigidos antes de crear la etiqueta `v1.0-rc0`.
