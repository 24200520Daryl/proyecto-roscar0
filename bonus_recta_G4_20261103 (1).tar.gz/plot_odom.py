#!/usr/bin/env python3
"""RC-0 RosCar2: genera trayectoria X-Y y angulo desenrollado desde ROSbag2.

Ejemplo (desde /root/yahboomcar_ws/rc0):
    python3 plot_odom.py bags/rc0_recta

Lee metadata.yaml para determinar sqlite3/mcap y guarda PNG en plots/.
"""
import argparse
import math
from pathlib import Path

import matplotlib
matplotlib.use('Agg')  # Entorno sin pantalla
import matplotlib.pyplot as plt
import numpy as np
import yaml
import rosbag2_py
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.serialization import deserialize_message


def leer_bag(bag):
    metadata_path = bag / 'metadata.yaml'
    if not metadata_path.is_file():
        raise FileNotFoundError(f'No existe {metadata_path}')

    with metadata_path.open('r', encoding='utf-8') as f:
        metadata = yaml.safe_load(f)['rosbag2_bagfile_information']
    storage_id = metadata['storage_identifier']
    if storage_id not in ('sqlite3', 'mcap'):
        raise ValueError(f'Formato de almacenamiento no soportado: {storage_id}')

    reader = rosbag2_py.SequentialReader()
    reader.open(
        rosbag2_py.StorageOptions(uri=str(bag.resolve()), storage_id=storage_id),
        rosbag2_py.ConverterOptions('cdr', 'cdr'),
    )
    tipos = {t.name: t.type for t in reader.get_all_topics_and_types()}
    if tipos.get('/odom') != 'nav_msgs/msg/Odometry':
        raise ValueError('El ROSbag no contiene /odom de tipo nav_msgs/msg/Odometry')

    filas, actividad = [], []
    while reader.has_next():
        topic, datos, timestamp = reader.read_next()
        if topic == '/odom':
            msg = deserialize_message(datos, Odometry)
            p = msg.pose.pose.position
            q = msg.pose.pose.orientation
            yaw = math.atan2(
                2.0 * (q.w * q.z + q.x * q.y),
                1.0 - 2.0 * (q.y * q.y + q.z * q.z),
            )
            filas.append((timestamp, p.x, p.y, yaw))
        elif topic == '/cmd_vel':
            cmd = deserialize_message(datos, Twist)
            if abs(cmd.linear.x) > 0.001 or abs(cmd.angular.z) > 0.001:
                actividad.append(timestamp)

    if len(filas) < 2:
        raise ValueError('No hay suficientes muestras de /odom para graficar')

    # Representar solo el movimiento, con 1 s antes y 3 s despues.
    # Si no hay comandos activos, utilizar todos los datos del ROSbag.
    if actividad:
        antes = min(actividad) - 1_000_000_000
        despues = max(actividad) + 3_000_000_000
        recorte = [f for f in filas if antes <= f[0] <= despues]
        if len(recorte) >= 2:
            filas = recorte

    muestras = np.asarray(filas, dtype=float)
    tiempo = (muestras[:, 0] - muestras[0, 0]) / 1e9
    x, y = muestras[:, 1], muestras[:, 2]
    angulo = np.degrees(np.unwrap(muestras[:, 3]))
    angulo -= angulo[0]
    return tiempo, x, y, angulo, storage_id


def graficar(bag, salida):
    t, x, y, theta, storage = leer_bag(bag)
    nombre = bag.name
    salida.mkdir(parents=True, exist_ok=True)

    # Gráfico 1: trayectoria X-Y, escala de ambos ejes igual.
    fig, ax = plt.subplots(figsize=(7, 5), constrained_layout=True)
    ax.plot(x, y, color='#2276a8', linewidth=2, label='/odom')
    ax.scatter([x[0]], [y[0]], color='#228b61', s=75, zorder=4, label='Inicio')
    ax.scatter([x[-1]], [y[-1]], color='#c87925', s=75, zorder=4, label='Fin')
    ax.set_aspect('equal', adjustable='datalim')
    ax.set_xlabel('Posicion X (m)')
    ax.set_ylabel('Posicion Y (m)')
    ax.set_title(f'{nombre} | Trayectoria X-Y')
    ax.grid(True, alpha=0.35)
    ax.legend(loc='best')
    ax.text(0.02, 0.02,
            f'Desplazamiento Y final: {y[-1] - y[0]:+.3f} m',
            transform=ax.transAxes, fontsize=9,
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.85))
    ruta_xy = salida / f'{nombre}_xy.png'
    fig.savefig(ruta_xy, dpi=180)
    plt.close(fig)

    # Gráfico 2: ángulo con unwrap para visualizar giros completos.
    fig, ax = plt.subplots(figsize=(7, 5), constrained_layout=True)
    ax.plot(t, theta, color='#2276a8', linewidth=2)
    ax.scatter([t[-1]], [theta[-1]], color='#c87925', s=65, zorder=4)
    if abs(theta[-1]) > 180:
        meta = 360 if theta[-1] > 0 else -360
        ax.axhline(meta, color='#b24b4b', ls='--', lw=1.4,
                   label=f'Referencia {meta:+d}°')
        ax.legend(loc='best')
    ax.set_xlabel('Tiempo relativo (s)')
    ax.set_ylabel('Angulo acumulado (grados)')
    ax.set_title(f'{nombre} | Orientacion vs. tiempo')
    ax.grid(True, alpha=0.35)
    ax.text(0.02, 0.96, f'Final: {theta[-1]:+.2f}°',
            transform=ax.transAxes, va='top', fontsize=10,
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.85))
    ruta_theta = salida / f'{nombre}_theta.png'
    fig.savefig(ruta_theta, dpi=180)
    plt.close(fig)

    print(f'OK | {nombre} | {storage} | /odom={len(t)} muestras')
    print(f'     {ruta_xy}')
    print(f'     {ruta_theta}')
    print(f'     Desplazamiento final: x={x[-1]-x[0]:+.3f} m, y={y[-1]-y[0]:+.3f} m; angulo={theta[-1]:+.2f}°')


def main():
    parser = argparse.ArgumentParser(description='Graficos de odometria de un ROSbag2')
    parser.add_argument('bag', type=Path, help='Carpeta ROSbag2 que contiene metadata.yaml')
    parser.add_argument('--out', type=Path, default=Path('plots'), help='Carpeta de salida PNG')
    args = parser.parse_args()
    graficar(args.bag, args.out)


if __name__ == '__main__':
    main()
